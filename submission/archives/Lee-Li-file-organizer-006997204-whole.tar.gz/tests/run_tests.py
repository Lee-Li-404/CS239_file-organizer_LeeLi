"""Run offline suites against this archive's src directory."""
import os
from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parents[1]
env = dict(os.environ, PYTHONPATH=str(root / 'src'))
for suite in (root / 'tests/file_organizer', root / 'tests'):
    result = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', str(suite), '-v'], cwd=root / 'src', env=env)
    if result.returncode:
        raise SystemExit(result.returncode)
